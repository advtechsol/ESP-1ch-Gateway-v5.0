# Code of Conduct

* Be nice
* Assume others mean well
